<template>
  <div class="home">

    <input type="text" placeholder="search" class="search-box" v-model="search">

    <Card v-for="(post) in posts" :key="post.id" :title="post.title" :body="post.body" v-if="searchFilter(post)"></Card>

  </div>
</template>

<script>
import Card from "@/components/Card.vue"
import axios from "axios"

export default {
  name: 'home',
  components: {
    Card
  },
  data() {
    return {
      posts: [],
      search: ""
    }
  },
  created() {
    axios.get("https://jsonplaceholder.typicode.com/posts").then((res) => {
      this.posts = res.data
    })
  },
  methods: {
    searchFilter(post) {
      let title = post.title
      let body = post.body

      if (title.includes(this.search) && body.includes(this.search)) {
        return true
      } else {
        return false
      }

    }
  }
}
</script>


<style scoped>
.search-box {
  font-size: 20px;
  display: block;
  width: 50%;
  padding: 15px;
  margin: 20px auto;
  border-radius: 50px;
  background: #34495e;
  border: 2px solid #2c3e50;
  color: white;
}
</style>