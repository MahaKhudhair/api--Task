<template>
    <div @click="toggleFullscreen()" :class="{fullscreen : isFullscreen}" class="card">
        <h3 class="card-title">{{ title }}</h3>
        <p class="card-body">{{ body }}</p>
    </div>
</template>


<script>
export default {
    props: ['title', 'body'],
    data() {
        return {
            isFullscreen: false,
        }
    },
    methods: {
        toggleFullscreen() {
            if (this.isFullscreen) this.isFullscreen = false; else this.isFullscreen = true;
        }
    }
}
</script>


<style scoped>
.card {
    display: inline-block;
    width: 200px;
    padding: 20px;
    margin: 20px;
    border-radius: 10px;
    box-shadow: 2px 2px 5px gray;
    height: 200px;
    overflow: hidden;
    background: #2c3e50;
}

.card-title {
    color: #ecf0f1;
}

.card-body {
    color: #bdc3c7;
}

.fullscreen {
    position: fixed;
    top: 0px;
    left: 0px;
    width: 100%;
    height: 100%;
    margin: 0px;
    text-align: center;
    padding: 100px 0px 0px 0px;
}

</style>